#!/bin/bash

echo "Starting configuration file deployment..."

# Use $HOME instead of hardcoded path
CONFIG_DIR="$HOME/Downloads/Config Files"
echo "Source directory: $CONFIG_DIR"

# Full paths of the config files
FASTFETCH_CONFIG="$CONFIG_DIR/fastfetch_config.jsonc"
WAYBAR_CONFIG="$CONFIG_DIR/waybar_config.jsonc"
WAYBAR_STYLE="$CONFIG_DIR/waybar_style.css"
CAVA_CONFIG="$CONFIG_DIR/cava_config"
HYPR_CONFIG="$CONFIG_DIR/hyprland.conf"
HYPR_KEYBINDS="$CONFIG_DIR/keybindings.conf"
HYPR_MONITORS="$CONFIG_DIR/monitors.conf"

# Function to create directory if it doesn't exist
create_dir() {
    if [ ! -d "$1" ]; then
        echo "Directory $1 does not exist. Creating it..."
        mkdir -p "$1"
        echo "Directory $1 created successfully."
    else
        echo "Directory $1 already exists."
    fi
}

# Function to copy files safely
copy_config() {
    if [ ! -f "$1" ]; then
        echo "ERROR: Source file $1 does not exist!"
        return 1
    fi

    if [ -f "$2" ]; then
        echo "Destination file $2 exists. Removing it..."
        rm "$2"
        echo "Old configuration file removed."
    fi

    echo "Copying $1 to $2..."
    cp "$1" "$2"
    if [ $? -eq 0 ]; then
        echo "File copied successfully."
    else
        echo "ERROR: Failed to copy file!"
        return 1
    fi
}

echo -e "\nCreating necessary directories..."
create_dir "$HOME/.config/fastfetch"
create_dir "$HOME/.config/waybar"
create_dir "$HOME/.config/cava"
create_dir "$HOME/.config/hypr"

echo -e "\nCopying configuration files..."

echo -e "\nProcessing Fastfetch configuration..."
copy_config "$FASTFETCH_CONFIG" "$HOME/.config/fastfetch/config.jsonc"

echo -e "\nProcessing Waybar configurations..."
copy_config "$WAYBAR_CONFIG" "$HOME/.config/waybar/config.jsonc"
copy_config "$WAYBAR_STYLE" "$HOME/.config/waybar/style.css"

echo -e "\nProcessing Cava configuration..."
copy_config "$CAVA_CONFIG" "$HOME/.config/cava/config"

echo -e "\nProcessing Hyprland configurations..."
copy_config "$HYPR_CONFIG" "$HOME/.config/hypr/hyprland.conf"
copy_config "$HYPR_KEYBINDS" "$HOME/.config/hypr/keybindings.conf"
copy_config "$HYPR_MONITORS" "$HOME/.config/hypr/monitors.conf"

echo -e "\nConfiguration deployment completed!"
